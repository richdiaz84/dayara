
    import React from 'react';
    import { Link } from 'react-router-dom';

    const HeaderLogo = () => {
      return (
        <Link to="/" className="flex items-center space-x-2 shrink-0">
          <img  alt="Dayara Nail Art Logo" className="h-8 sm:h-10 md:h-12 object-contain" src="https://images.unsplash.com/photo-1649000808933-1f4aac7cad9a" />
          <span className="font-bold text-xl sm:text-2xl text-primary hidden xs:inline">Dayara</span>
        </Link>
      );
    };

    export default HeaderLogo;
  