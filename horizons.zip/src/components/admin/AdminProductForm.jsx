
    import React, { useState, useEffect, useCallback } from 'react';
    import { supabase } from '@/lib/supabaseClient';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Textarea } from '@/components/ui/textarea';
    import { Checkbox } from '@/components/ui/checkbox';
    import { useToast } from '@/components/ui/use-toast';
    import { Loader2, Video as VideoIcon } from 'lucide-react';
    import ProductFormImages from '@/components/admin/product-form/ProductFormImages';
    import ProductFormVideos from '@/components/admin/product-form/ProductFormVideos';
    import { 
      handleImageUpload, 
      handleImageRemoval, 
      deleteStoredImages 
    } from '@/lib/productImageUtils';

    const initialFormData = {
      name: '',
      description: '',
      price: '',
      stock: '',
      category: '',
      is_published: true,
    };

    const AdminProductForm = ({ product, onSave, onCancel }) => {
      const [formData, setFormData] = useState(initialFormData);
      const [currentImages, setCurrentImages] = useState([]);
      const [newImageFiles, setNewImageFiles] = useState([]);
      const [videos, setVideos] = useState([]);
      const [isVideosLoading, setIsVideosLoading] = useState(false);
      const [isLoading, setIsLoading] = useState(false);
      const { toast } = useToast();

      const fetchProductVideos = useCallback(async (productId) => {
        if (!productId) return;
        setIsVideosLoading(true);
        try {
          const { data, error } = await supabase
            .from('product_videos')
            .select('*')
            .eq('product_id', productId)
            .order('video_order', { ascending: true });
          if (error) throw error;
          setVideos(data || []);
        } catch (error) {
          toast({ variant: "destructive", title: "Error", description: "No se pudieron cargar los videos del producto."});
        } finally {
          setIsVideosLoading(false);
        }
      }, [toast]);

      useEffect(() => {
        if (product) {
          setFormData({
            name: product.name || '',
            description: product.description || '',
            price: product.price || '',
            stock: product.stock || '',
            category: product.category || '',
            is_published: product.is_published !== undefined ? product.is_published : true,
          });
          setCurrentImages(product.images || []);
          setNewImageFiles([]);
          if (product.id) {
            fetchProductVideos(product.id);
          } else {
            setVideos([]);
          }
        } else {
          setFormData(initialFormData);
          setCurrentImages([]);
          setNewImageFiles([]);
          setVideos([]);
        }
      }, [product, fetchProductVideos]);

      const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
      };

      const handleSubmit = async (e) => {
        e.preventDefault();
        setIsLoading(true);

        let finalImageUrls = [...currentImages];
        let productId = product?.id;

        try {
          // Handle image uploads and deletions
          if (newImageFiles.length > 0) {
            const uploadedUrls = await handleImageUpload(newImageFiles, productId || `temp-${Date.now()}`, toast);
            if (!productId) { 
                 finalImageUrls = uploadedUrls;
            } else {
                 finalImageUrls = [...currentImages, ...uploadedUrls];
            }
          }
          
          // Construct product data payload
          const productDataPayload = { 
            ...formData, 
            price: parseFloat(formData.price) || 0, 
            stock: parseInt(formData.stock, 10) || 0,
            images: finalImageUrls 
          };
          
          let savedProduct;

          if (!productId) { // Creating new product
            const tempImages = productDataPayload.images;
            productDataPayload.images = []; // Insert without images first if new

            const { data: newProduct, error: insertError } = await supabase
              .from('products')
              .insert([productDataPayload])
              .select()
              .single();

            if (insertError) throw insertError;
            savedProduct = newProduct;
            productId = newProduct.id;

            // Update product with correctly pathed images
            if (newImageFiles.length > 0) {
                const correctlyPathedImages = tempImages.map(url => url.replace(/temp-.[^\/]+/, productId));
                const { error: updateImgError } = await supabase
                    .from('products')
                    .update({ images: correctlyPathedImages })
                    .eq('id', productId);
                if (updateImgError) throw updateImgError;
                savedProduct.images = correctlyPathedImages;
                finalImageUrls = correctlyPathedImages; 
            } else {
              savedProduct.images = [];
            }

          } else { // Updating existing product
             if (product.images && product.images.length > 0) {
                // Delete images removed from currentImages list compared to original product.images
                const imagesToDelete = product.images.filter(url => !finalImageUrls.includes(url));
                if (imagesToDelete.length > 0) {
                    await deleteStoredImages(imagesToDelete, toast);
                }
             }
            productDataPayload.images = finalImageUrls;
            const { data: updatedProduct, error: updateError } = await supabase
              .from('products')
              .update(productDataPayload)
              .eq('id', productId)
              .select()
              .single();
            if (updateError) throw updateError;
            savedProduct = updatedProduct;
          }
          
          toast({ title: "Éxito", description: `Producto ${product ? 'actualizado' : 'creado'} correctamente.` });
          onSave(savedProduct);
        } catch (error) {
          console.error("Error saving product:", error);
          toast({ variant: "destructive", title: "Error", description: `No se pudo guardar el producto: ${error.message}` });
        } finally {
          setIsLoading(false);
        }
      };

      return (
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="name">Nombre del Producto</Label>
            <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
          </div>
          <div>
            <Label htmlFor="description">Descripción</Label>
            <Textarea id="description" name="description" value={formData.description} onChange={handleChange} />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="price">Precio</Label>
              <Input id="price" name="price" type="number" step="0.01" value={formData.price} onChange={handleChange} required />
            </div>
            <div>
              <Label htmlFor="stock">Stock</Label>
              <Input id="stock" name="stock" type="number" value={formData.stock} onChange={handleChange} required />
            </div>
          </div>
          <div>
            <Label htmlFor="category">Categoría</Label>
            <Input id="category" name="category" value={formData.category} onChange={handleChange} />
          </div>
          
          <ProductFormImages
            currentImages={currentImages}
            newImageFiles={newImageFiles}
            onCurrentImageRemove={(index) => handleImageRemoval(index, currentImages, setCurrentImages)}
            onNewImageFileRemove={(index) => setNewImageFiles(prev => prev.filter((_, i) => i !== index))}
            onNewImageFilesChange={(files) => setNewImageFiles(files)}
          />

          <div className="flex items-center space-x-2">
            <Checkbox id="is_published" name="is_published" checked={formData.is_published} onCheckedChange={(checked) => setFormData(prev => ({...prev, is_published: Boolean(checked)}))} />
            <Label htmlFor="is_published">Publicar producto</Label>
          </div>
          
          {product && product.id && (
            <ProductFormVideos
              productId={product.id}
              initialVideos={videos}
              isLoadingExternal={isVideosLoading}
              onVideosUpdate={fetchProductVideos} 
            />
          )}

          <div className="flex justify-end space-x-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onCancel} disabled={isLoading}>Cancelar</Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {product ? 'Actualizar Producto' : 'Crear Producto'}
            </Button>
          </div>
        </form>
      );
    };

    export default AdminProductForm;
  