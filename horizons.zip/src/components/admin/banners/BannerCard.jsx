
    import React from 'react';
    import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Button } from '@/components/ui/button';
    import { Badge } from '@/components/ui/badge';
    import { Calendar, Edit, Trash2, Eye, EyeOff, Link as LinkIcon } from 'lucide-react';
    import { format } from 'date-fns';
    import { es } from 'date-fns/locale';
    import { motion } from 'framer-motion';

    const BannerCard = ({ banner, onEdit, onDelete, onTogglePublish }) => {
      const cardVariants = {
        hidden: { opacity: 0, scale: 0.95 },
        visible: { opacity: 1, scale: 1 }
      };

      const formatDate = (dateString) => {
        if (!dateString) return 'N/A';
        try {
          return format(new Date(dateString), "dd MMM yyyy", { locale: es });
        } catch (e) {
          return 'Fecha inválida';
        }
      };

      const isActive = banner.active && 
                       (!banner.start_date || new Date(banner.start_date) <= new Date()) && 
                       (!banner.end_date || new Date(banner.end_date) >= new Date());

      return (
        <motion.div variants={cardVariants}>
          <Card className="overflow-hidden bg-card/70 backdrop-blur-md shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col h-full">
            <CardHeader className="p-4 border-b">
              <div className="flex justify-between items-start">
                <CardTitle className="text-lg font-semibold text-foreground">{banner.title}</CardTitle>
                <Badge variant={isActive ? "default" : "outline"} className={`${isActive ? 'bg-green-500/20 text-green-700 border-green-500/30' : 'bg-red-500/20 text-red-700 border-red-500/30'} text-xs`}>
                  {isActive ? 'Activo' : 'Inactivo'}
                </Badge>
              </div>
              {banner.description && <CardDescription className="text-xs text-muted-foreground mt-1 line-clamp-2">{banner.description}</CardDescription>}
            </CardHeader>
            <CardContent className="p-4 flex-grow">
              {banner.image_url ? (
                <div className="aspect-video rounded-md overflow-hidden mb-3 bg-muted">
                  <img 
                    src={banner.image_url}
                    alt={banner.title}
                    className="w-full h-full object-cover"
                   src="https://images.unsplash.com/photo-1637425792838-1024f2012f0d" />
                </div>
              ) : (
                <div className="aspect-video rounded-md overflow-hidden mb-3 bg-muted flex items-center justify-center text-muted-foreground">
                  Sin Imagen
                </div>
              )}
              
              <div className="space-y-1 text-xs text-muted-foreground">
                <div className="flex items-center">
                  <Calendar className="h-3.5 w-3.5 mr-1.5" />
                  <span>Inicio: {formatDate(banner.start_date)}</span>
                </div>
                <div className="flex items-center">
                  <Calendar className="h-3.5 w-3.5 mr-1.5" />
                  <span>Fin: {formatDate(banner.end_date)}</span>
                </div>
                {banner.product_id && (
                  <div className="flex items-center">
                    <LinkIcon className="h-3.5 w-3.5 mr-1.5" />
                    <span>Enlazado a producto ID: <span className="font-medium text-foreground">{banner.product_id.substring(0,8)}...</span></span>
                  </div>
                )}
              </div>
            </CardContent>
            <CardFooter className="p-3 bg-muted/30 border-t flex gap-2">
              <Button variant="outline" size="sm" onClick={() => onEdit(banner)} className="flex-1">
                <Edit className="h-4 w-4 mr-1.5" /> Editar
              </Button>
              <Button variant={banner.active ? "secondary" : "default"} size="sm" onClick={() => onTogglePublish(banner)} className="flex-1">
                {banner.active ? <EyeOff className="h-4 w-4 mr-1.5" /> : <Eye className="h-4 w-4 mr-1.5" />}
                {banner.active ? 'Despublicar' : 'Publicar'}
              </Button>
              <Button variant="destructive" size="icon_sm" onClick={() => onDelete(banner)}>
                <Trash2 className="h-4 w-4" />
                <span className="sr-only">Eliminar</span>
              </Button>
            </CardFooter>
          </Card>
        </motion.div>
      );
    };

    export default BannerCard;
  