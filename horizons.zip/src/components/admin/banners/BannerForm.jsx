
    import React, { useState, useEffect } from 'react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Textarea } from '@/components/ui/textarea';
    import { Label } from '@/components/ui/label';
    import { Checkbox } from '@/components/ui/checkbox';
    import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';
    import { Loader2 } from 'lucide-react';

    const BannerForm = ({ bannerToEdit, onFormSubmit, onCancel, isLoading }) => {
      const { toast } = useToast();
      const [title, setTitle] = useState('');
      const [description, setDescription] = useState('');
      const [imageUrl, setImageUrl] = useState('');
      const [imageFile, setImageFile] = useState(null);
      const [linkUrl, setLinkUrl] = useState('');
      const [active, setActive] = useState(true);
      const [startDate, setStartDate] = useState('');
      const [endDate, setEndDate] = useState('');
      const [previewUrl, setPreviewUrl] = useState('');

      useEffect(() => {
        if (bannerToEdit) {
          setTitle(bannerToEdit.title || '');
          setDescription(bannerToEdit.description || '');
          setImageUrl(bannerToEdit.image_url || '');
          setPreviewUrl(bannerToEdit.image_url || '');
          setLinkUrl(bannerToEdit.link_url || '');
          setActive(bannerToEdit.active === undefined ? true : bannerToEdit.active);
          setStartDate(bannerToEdit.start_date ? bannerToEdit.start_date.split('T')[0] : '');
          setEndDate(bannerToEdit.end_date ? bannerToEdit.end_date.split('T')[0] : '');
          setImageFile(null);
        } else {
          setTitle(''); setDescription(''); setImageUrl(''); setPreviewUrl(''); setImageFile(null);
          setLinkUrl(''); setActive(true); setStartDate(''); setEndDate('');
        }
      }, [bannerToEdit]);

      const handleImageFileChange = (e) => {
        const file = e.target.files[0];
        if (file) {
          setImageFile(file);
          setPreviewUrl(URL.createObjectURL(file)); 
        }
      };

      const handleSubmit = async (e) => {
        e.preventDefault();
        if (!title || (!imageFile && !imageUrl && !bannerToEdit?.image_url)) {
          toast({ variant: "destructive", title: "Error", description: "Título e imagen son obligatorios." });
          return;
        }

        let finalImageUrl = bannerToEdit?.image_url || imageUrl;

        if (imageFile) {
          const fileName = `banner_${Date.now()}_${imageFile.name.replace(/\s+/g, '_')}`;
          const { data: uploadData, error: uploadError } = await supabase.storage
            .from('banner_images')
            .upload(fileName, imageFile, { upsert: true });

          if (uploadError) {
            toast({ variant: "destructive", title: "Error de subida", description: uploadError.message });
            return;
          }
          const { data: { publicUrl } } = supabase.storage.from('banner_images').getPublicUrl(uploadData.path);
          finalImageUrl = publicUrl;
        }
        
        const bannerData = {
          title,
          description,
          image_url: finalImageUrl,
          link_url: linkUrl || null,
          active,
          start_date: startDate || null,
          end_date: endDate || null,
        };
        onFormSubmit(bannerData, bannerToEdit ? bannerToEdit.id : null);
      };

      return (
        <Card className="w-full max-w-2xl mx-auto shadow-xl bg-card">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-center text-foreground">
              {bannerToEdit ? 'Editar Banner' : 'Añadir Nuevo Banner'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} id="banner-form" className="space-y-6">
              <div>
                <Label htmlFor="title" className="text-muted-foreground">Título</Label>
                <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} required className="mt-1 bg-input text-foreground border-border focus:border-primary" />
              </div>
              <div>
                <Label htmlFor="description" className="text-muted-foreground">Descripción (opcional)</Label>
                <Textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} className="mt-1 bg-input text-foreground border-border focus:border-primary" />
              </div>
              <div>
                <Label htmlFor="imageFile" className="text-muted-foreground">Imagen del Banner</Label>
                <Input id="imageFile" type="file" onChange={handleImageFileChange} accept="image/*" className="mt-1 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary file:text-primary-foreground hover:file:bg-primary/90" />
                {previewUrl && <img  src={previewUrl} alt="Vista previa del banner" className="mt-2 rounded-md max-h-40 object-contain border p-1" />}
              </div>
              <div>
                <Label htmlFor="linkUrl" className="text-muted-foreground">URL de Enlace (opcional)</Label>
                <Input id="linkUrl" type="url" value={linkUrl} onChange={(e) => setLinkUrl(e.target.value)} placeholder="https://ejemplo.com/producto" className="mt-1 bg-input text-foreground border-border focus:border-primary" />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="startDate" className="text-muted-foreground">Fecha de Inicio (opcional)</Label>
                  <Input id="startDate" type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="mt-1 bg-input text-foreground border-border focus:border-primary" />
                </div>
                <div>
                  <Label htmlFor="endDate" className="text-muted-foreground">Fecha de Fin (opcional)</Label>
                  <Input id="endDate" type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} className="mt-1 bg-input text-foreground border-border focus:border-primary" />
                </div>
              </div>
              <div className="flex items-center space-x-2 pt-2">
                <Checkbox id="active" checked={active} onCheckedChange={setActive} />
                <Label htmlFor="active" className="text-muted-foreground">Activo</Label>
              </div>
            </form>
          </CardContent>
           <CardFooter className="flex justify-end space-x-4 p-4 pt-6">
            <Button type="button" variant="outline" onClick={onCancel} disabled={isLoading}>
              Cancelar
            </Button>
            <Button type="submit" form="banner-form" disabled={isLoading} className="bg-primary hover:bg-primary/90 text-primary-foreground">
              {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {bannerToEdit ? 'Actualizar Banner' : 'Guardar Banner'}
            </Button>
          </CardFooter>
        </Card>
      );
    };
    export default BannerForm;
  